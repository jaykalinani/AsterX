#include "hdf5imple.h"
#include "eos_barotr_file.h"
#include "eos_barotr_file_impl.h"
#include "eos_barotr_poly_impl.h"
#include "eos_barotr_pwpoly_impl.h"
#include "eos_barotr_table_impl.h"


namespace EOS_Toolkit {


eos_barotr detail::load_eos_barotr(const h5grp& g, const units& u)
{
  //This is only here to workaround linker in static library case
  const bool builtin_handlers_registered{
    EOS_Toolkit::implementations::eos_barotr_pwpoly::file_handler_registered &&
    EOS_Toolkit::implementations::eos_barotr_poly::file_handler_registered &&
    EOS_Toolkit::implementations::eos_barotr_table::file_handler_registered
  };
  assert(builtin_handlers_registered);
  
  
  
  std::string spec = get_attribute<std::string>(g, "eos_type");
  
  h5grp g2(g, std::string("eos_")+spec);

  auto& r = implementations::registry_reader_eos_barotr::get(spec);
  return r.load(g2,u);  
}

eos_barotr load_eos_barotr(std::string fname, const units& u)
{
  h5file f(fname);
  h5grp g(f, "/");
  return detail::load_eos_barotr(g,u);
}


} // namespace EOS_Toolkit
