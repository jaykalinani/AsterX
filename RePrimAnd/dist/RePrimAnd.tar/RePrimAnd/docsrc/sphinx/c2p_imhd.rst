Primitive Recovery
==================

The core functionality provided by the library is the recovery
of primitive variables from variables evolved in ideal 
magnetohydrodynamics. For details of the method we refer to the
article this code belongs to. Here we describe on the provided 
functionality and the code interface.

.. toctree::
   :maxdepth: 1

   c2p_imhd_feat
   c2p_imhd_interf
   c2p_imhd_ref
