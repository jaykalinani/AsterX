Reference
---------


Generic Interface
^^^^^^^^^^^^^^^^^
.. doxygenclass:: EOS_Toolkit::eos_barotr
   :project: RePrimAnd
   :members:

Loading from File
^^^^^^^^^^^^^^^^^

.. doxygenfunction:: EOS_Toolkit::load_eos_barotr
   :project: RePrimAnd


Creating Specific EOS
^^^^^^^^^^^^^^^^^^^^^

.. doxygenfunction:: EOS_Toolkit::make_eos_barotr_table
   :project: RePrimAnd

|

.. doxygenfunction:: EOS_Toolkit::make_eos_barotr_poly
   :project: RePrimAnd

|

.. doxygenfunction:: EOS_Toolkit::make_eos_barotr_pwpoly
   :project: RePrimAnd

