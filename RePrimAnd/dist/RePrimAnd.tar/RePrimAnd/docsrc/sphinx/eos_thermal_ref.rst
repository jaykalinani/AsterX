
Reference
---------

Generic Interface
^^^^^^^^^^^^^^^^^

.. doxygenclass:: EOS_Toolkit::eos_thermal
   :project: RePrimAnd
   :members:

Loading from File
^^^^^^^^^^^^^^^^^

.. doxygenfunction:: EOS_Toolkit::load_eos_thermal
   :project: RePrimAnd

Creating Specific EOS
^^^^^^^^^^^^^^^^^^^^^

.. doxygenfunction:: EOS_Toolkit::make_eos_hybrid
   :project: RePrimAnd

.. doxygenfunction:: EOS_Toolkit::make_eos_idealgas
   :project: RePrimAnd
